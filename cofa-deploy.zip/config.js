// Configuración central. Todo dato marcado PENDING debe completarlo el negocio; no se inventa.
const COFA_CONFIG = {
  brand: "COFA Tours and Fishing",
  whatsapp: "50671444364",          // tomado de las versiones HTML existentes
  bookingApi: null,                 // PENDING: URL de backend de reservas (POST JSON). null = solo WhatsApp
  pricesConfirmed: false,           // poner true cuando se validen los 20 precios en conflicto (data/price-conflicts.json)
  legal: { legalName: null, cedulaJuridica: null, icT: null, address: null, email: null, phone: null }, // PENDING
  currency: "USD"
};
if (typeof module !== "undefined") module.exports = COFA_CONFIG;
