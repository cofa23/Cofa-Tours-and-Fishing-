(() => {
const C = COFA_CONFIG, $ = s => document.querySelector(s);
const store = { get(k, d) { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} } };
let DATA, lang = store.get("cofa_lang", (navigator.language || "es").startsWith("en") ? "en" : "es"), cart = store.get("cofa_cart", []);
let filter = "All", q = "", lastForm = store.get("cofa_form", {});
const t = k => I18N[lang][k] || k;
const imgSrc = it => /^https?:/.test(it.image) ? it.image : "/" + it.image.replace(/^\//, "");
const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const catName = c => lang === "es" ? DATA.categories[c] : CAT_EN[c];
const priceHTML = it => `<strong>${it.priceOnRequest ? t("from") + " " : ""}${Core.money(it.price)}</strong> <small>${it.unit === "group" ? t("per_group") : t("per_person")}${!C.pricesConfirmed ? " · " + t("confirm_price") : ""}</small>`;
const saveCart = () => { store.set("cofa_cart", cart); badge(); };
const badge = () => { const n = cart.reduce((s, l) => s + l.qty, 0); $("#cartCount").textContent = n; $("#cartCount").hidden = !n; };

function setMeta(title, desc, path) {
  document.title = title;
  $('meta[name=description]').content = desc;
  $('meta[property="og:title"]').content = title;
  $('meta[property="og:description"]').content = desc;
  const url = location.origin + path;
  $('link[rel=canonical]').href = url; $('meta[property="og:url"]').content = url;
  document.documentElement.lang = lang;
}
function chrome() {
  $("#nExp").textContent = t("nav_exp"); $("#nCart").firstChild.textContent = t("nav_cart") + " ";
  $("#nPol").textContent = t("nav_pol"); $(".skip").textContent = t("skip"); $("#foot").textContent = "© " + C.brand + " • " + t("footer");
  $("#langBtn").textContent = lang === "es" ? "EN" : "ES"; $("#langBtn").setAttribute("aria-label", lang === "es" ? "Switch to English" : "Cambiar a español");
  badge();
}
function card(it) {
  return `<article class="card"><a href="/experiences/${it.id}" data-link><img src="${esc(imgSrc(it))}" alt="${esc(it.title)} - Jacó, Costa Rica" loading="lazy" width="400" height="260" onerror="this.onerror=null;this.src='/assets/logo.webp';this.classList.add('ph')"></a>
  <div class="cb"><span class="tag">${esc(catName(it.category))}</span><h3><a href="/experiences/${it.id}" data-link>${esc(it.title)}</a></h3>
  <p class="meta">${esc(it.duration)}</p><p>${esc(it.desc[lang])}</p><p class="price">${priceHTML(it)}</p>
  <div class="row"><a class="btn ghost" href="/experiences/${it.id}" data-link>${t("view")}</a><button class="btn" data-add="${it.id}">${t("add")}</button></div></div></article>`;
}
function home() {
  setMeta(lang === "es" ? "COFA Tours and Fishing | Pesca deportiva y tours en Jacó, Costa Rica" : "COFA Tours and Fishing | Sport Fishing & Tours in Jacó, Costa Rica",
    lang === "es" ? "Pesca deportiva, catamarán a Isla Tortuga, ATV, canopy, rafting y parques nacionales desde Jacó. Solicita tu reserva por WhatsApp." : "Sport fishing, Tortuga Island catamaran, ATV, zip line, rafting and national parks from Jacó. Request your booking on WhatsApp.", "/");
  const cats = ["All", ...Object.keys(DATA.categories)];
  const list = DATA.items.filter(i => (filter === "All" || i.category === filter) && (i.title + " " + i.desc[lang]).toLowerCase().includes(q.toLowerCase()));
  $("#app").innerHTML = `<section class="hero"><img src="/assets/logo.webp" alt="COFA Tours and Fishing logo" width="96" height="96"><div><h1>${t("h1")}</h1><p>${t("sub")}</p></div></section>
  <div class="tools"><label class="sr" for="q">${t("search")}</label><input id="q" type="search" placeholder="${t("search")}" value="${esc(q)}">
  <div class="chips" role="group">${cats.map(c => `<button class="chip" aria-pressed="${c === filter}" data-cat="${c}">${c === "All" ? t("all") : esc(catName(c))}</button>`).join("")}</div></div>
  ${!C.pricesConfirmed ? `<p class="note">${t("price_note")}</p>` : ""}
  <div class="grid" id="grid">${list.map(card).join("") || `<p>${t("none")}</p>`}</div>`;
  $("#q").addEventListener("input", e => { q = e.target.value; const pos = e.target.selectionStart; home(); const n = $("#q"); n.focus(); n.setSelectionRange(pos, pos); });
}
function detail(id) {
  const it = DATA.items.find(i => i.id === id); if (!it) return notFound();
  setMeta(`${it.title} | COFA Tours and Fishing Jacó`, it.desc[lang].slice(0, 155), "/experiences/" + id);
  addLd(it);
  $("#app").innerHTML = `<a href="/" data-link class="back">← ${t("back")}</a><article class="detail"><img src="${esc(imgSrc(it))}" alt="${esc(it.title)} - Jacó, Costa Rica" width="800" height="520" onerror="this.onerror=null;this.src='/assets/logo.webp';this.classList.add('ph')">
  <div><span class="tag">${esc(catName(it.category))}</span><h1>${esc(it.title)}</h1><p>${esc(it.desc[lang])}</p>
  <dl><dt>${t("duration")}</dt><dd>${esc(it.duration)}</dd><dt>${t("location")}</dt><dd>${t("loc_val")}</dd></dl>
  <h2>${t("includes")}</h2><ul>${it.includes.map(x => `<li>${esc(x)}</li>`).join("")}</ul>
  <h2>${t("important")}</h2><ul><li>${t("imp1")}</li><li>${t("imp2")}</li></ul>
  <p class="price">${priceHTML(it)}</p>
  <div class="row"><label>${t("people")} <input id="qty" type="number" min="1" max="50" value="2" inputmode="numeric"></label><button class="btn" data-add="${it.id}" data-qtyinput>${t("add")}</button></div></div></article>`;
}
function addLd(it) {
  const old = $("#ld-exp"); if (old) old.remove();
  const s = document.createElement("script"); s.type = "application/ld+json"; s.id = "ld-exp";
  s.textContent = JSON.stringify({ "@context": "https://schema.org", "@type": "TouristTrip", name: it.title, description: it.desc.en, touristType: "Visitors to Costa Rica",
    provider: { "@type": "TravelAgency", name: C.brand }, offers: { "@type": "Offer", price: it.price, priceCurrency: "USD" } });
  document.head.appendChild(s);
}
function cartView() {
  setMeta(t("cart_title") + " | COFA", t("sub"), "/cart");
  const rows = cart.map(l => { const it = DATA.items.find(i => i.id === l.id); if (!it) return "";
    return `<li class="line"><div><strong>${esc(it.title)}</strong><br><small>${esc(it.duration)} · ${it.unit === "group" ? t("per_group") : t("per_person")}</small></div>
    <label class="sr" for="q-${it.id}">${t("people")}</label><input id="q-${it.id}" type="number" min="1" max="50" value="${l.qty}" data-qty="${it.id}" inputmode="numeric">
    <span>${Core.money(Core.lineTotal(it, l.qty))}</span><button class="btn ghost" data-rm="${it.id}">${t("remove")}</button></li>`; }).join("");
  $("#app").innerHTML = `<h1>${t("cart_title")}</h1>` + (cart.length ? `<ul class="lines">${rows}</ul><p class="total">${t("total")}: <strong id="tot">${Core.money(Core.cartTotal(cart, DATA.items))}</strong></p>${!C.pricesConfirmed ? `<p class="note">${t("price_note")}</p>` : ""}<a class="btn" href="/book" data-link>${t("cont")}</a>`
    : `<p>${t("empty")}</p><a class="btn" href="/" data-link>${t("browse")}</a>`);
}
function book(done) {
  if (!cart.length && !done) return nav("/cart");
  setMeta(t("book_title") + " | COFA", t("sub"), "/book");
  const tomorrow = new Date(Date.now() + 864e5); const min = `${tomorrow.getFullYear()}-${String(tomorrow.getMonth() + 1).padStart(2, "0")}-${String(tomorrow.getDate()).padStart(2, "0")}`;
  const total = Core.cartTotal(cart, DATA.items), f = lastForm, g = f.guests || cart.reduce((s, l) => s + l.qty, 0) || 2;
  const fld = (id, label, type, extra = "") => `<div class="fld"><label for="${id}">${label}</label><input id="${id}" name="${id}" type="${type}" value="${esc(f[id] || "")}" ${extra}><small class="err" id="e-${id}" role="alert"></small></div>`;
  $("#app").innerHTML = `<h1>${t("book_title")}</h1><div class="two"><form id="bf" novalidate>
  ${fld("name", t("f_name"), "text", 'autocomplete="name" required')}${fld("phone", t("f_phone"), "tel", 'autocomplete="tel" inputmode="tel" required')}${fld("email", t("f_email"), "email", 'autocomplete="email"')}
  ${fld("date", t("f_date"), "date", `min="${min}" required`)}${fld("time", t("f_time"), "time")}${fld("guests", t("f_guests"), "number", `min="1" max="50" inputmode="numeric" required`).replace(`value="${esc(f.guests || "")}"`, `value="${g}"`)}
  <div class="fld"><label for="notes">${t("f_notes")}</label><textarea id="notes" rows="3">${esc(f.notes || "")}</textarea></div>
  <button class="btn big" type="submit">${t("send")}</button><p class="note">${t("sending_note")}</p></form>
  <aside class="sum"><h2>${t("summary")}</h2><ul>${cart.map(l => { const it = DATA.items.find(i => i.id === l.id); return it ? `<li>${esc(it.title)} ×${l.qty} — ${Core.money(Core.lineTotal(it, l.qty))}</li>` : ""; }).join("")}</ul>
  <p class="total">${t("total")}: <strong>${Core.money(total)}</strong></p><h2>${t("pay")}</h2><p>${t("pay_val")}</p></aside></div>`;
  $("#bf").addEventListener("submit", async e => {
    e.preventDefault(); const form = Object.fromEntries(["name", "phone", "email", "date", "time", "guests", "notes"].map(k => [k, $("#" + k).value]));
    lastForm = form; store.set("cofa_form", form);
    const errs = Core.validate(form, new Date().toLocaleDateString("sv"));
    ["name", "phone", "email", "date", "guests"].forEach(k => $("#e-" + k).textContent = errs[k] ? t("e_" + k) : "");
    if (Object.keys(errs).length) { $("#" + Object.keys(errs)[0]).focus(); return; }
    const msg = Core.message(lang, cart, DATA.items, form, total, C), req = { form, cart, total, lang, createdAt: new Date().toISOString() };
    const reqs = store.get("cofa_requests", []); reqs.push(req); store.set("cofa_requests", reqs);
    if (C.bookingApi) { try { await fetch(C.bookingApi, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(req) }); } catch {} }
    const url = Core.waUrl(C.whatsapp, msg); window.open(url, "_blank", "noopener");
    $("#app").innerHTML = `<h1>${t("done_title")}</h1><p>${t("done_txt")}</p><a class="btn" href="${esc(url)}" target="_blank" rel="noopener">${t("open_wa")}</a> <a class="btn ghost" href="/" data-link>${t("browse")}</a>`;
  });
}
function policies() {
  setMeta(t("pol_title") + " | COFA", t("sub"), "/policies");
  const row = (l, v) => `<dt>${l}</dt><dd>${v || `<em class="pend">${t("pending")}</em>`}</dd>`, L = C.legal;
  $("#app").innerHTML = `<h1>${t("pol_title")}</h1><h2>${t("pol_cancel")}</h2><p class="pend">${t("pending")}</p><h2>${t("pol_legal")}</h2><dl>${row("Legal", L.legalName)}${row("Cédula jurídica", L.cedulaJuridica)}${row("ICT", L.icT)}${row("Address", L.address)}${row("Email", L.email)}${row(t("pol_wa"), `<a href="https://wa.me/${C.whatsapp}" rel="noopener">+${C.whatsapp}</a>`)}</dl>`;
}
function notFound() { setMeta("404 | COFA", "", location.pathname); $("#app").innerHTML = `<h1>404</h1><a class="btn" href="/" data-link>${t("browse")}</a>`; }
function route() {
  const p = location.pathname.replace(/\/+$/, "") || "/", m = p.match(/^\/experiences\/([\w-]+)$/);
  const ld = $("#ld-exp"); if (ld && !m) ld.remove();
  chrome();
  if (p === "/") home(); else if (m) detail(m[1]); else if (p === "/cart") cartView(); else if (p === "/book") book(); else if (p === "/policies") policies(); else notFound();
  scrollTo(0, 0);
}
function nav(p) { history.pushState({}, "", p); route(); }
document.addEventListener("click", e => {
  const a = e.target.closest("a[data-link]"); if (a) { e.preventDefault(); nav(a.getAttribute("href")); return; }
  const add = e.target.closest("[data-add]");
  if (add) { const qty = add.hasAttribute("data-qtyinput") ? $("#qty").value : 1; cart = Core.addToCart(cart, add.dataset.add, qty); saveCart(); const o = add.textContent; add.textContent = "✓ " + t("added"); setTimeout(() => add.textContent = o, 1200); }
  const rm = e.target.closest("[data-rm]"); if (rm) { cart = Core.remove(cart, rm.dataset.rm); saveCart(); cartView(); }
  const ch = e.target.closest("[data-cat]"); if (ch) { filter = ch.dataset.cat; home(); }
});
document.addEventListener("change", e => { const el = e.target.closest("[data-qty]"); if (el) { cart = Core.setQty(cart, el.dataset.qty, el.value); saveCart(); cartView(); } });
$("#langBtn").addEventListener("click", () => { lang = lang === "es" ? "en" : "es"; store.set("cofa_lang", lang); route(); });
addEventListener("popstate", route);
addEventListener("offline", () => { $("#toast").textContent = t("offline"); $("#toast").hidden = false; });
addEventListener("online", () => $("#toast").hidden = true);
fetch("/data/experiences.json").then(r => r.json()).then(d => { DATA = d; cart = cart.filter(l => d.items.some(i => i.id === l.id)); route(); })
  .catch(() => { $("#app").textContent = "Error loading catalog."; });
if ("serviceWorker" in navigator) addEventListener("load", () => navigator.serviceWorker.register("/sw.js").catch(() => {}));
})();
