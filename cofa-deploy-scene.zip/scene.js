// Escena inmersiva de COFA. Ilustración SVG en capas (no son fotos). Datos de ejemplo del catálogo existente.
// `pano`: reservado para fotografías 360° reales (aún no hay ninguna; no se inventa).
(() => {
const VB = [1000, 640];
const HS = [
  { id: "sunset",    x: 230, y: 300, mood: "sunset",  ex: ["horse-sunset", "rzr-sunset", "sushi-chef"], pano: null },
  { id: "volcano",   x: 715, y: 262, mood: "volcano", ex: ["la-fortuna"], pano: null },
  { id: "waterfall", x: 822, y: 368, mood: "water",   ex: ["atv-waterfall", "canyoning"], pano: null },
  { id: "river",     x: 705, y: 484, mood: "river",   ex: ["rafting", "tarcoles-safari"], pano: null },
  { id: "ocean",     x: 150, y: 455, mood: "ocean",   ex: ["surf", "sport-fishing", "kayak-snorkel"], pano: null },
  { id: "animal",    x: 800, y: 172, mood: "wild",    ex: ["bird-watching", "monkey-4in1", "carara"], pano: null },
  { id: "forest",    x: 880, y: 520, mood: "forest",  ex: ["monteverde", "manuel-antonio"], pano: null },
  { id: "adventure", x: 560, y: 596, mood: "adv",     ex: ["atv-jungle", "zip-line", "paragliding"], pano: null }
];
const TXT = {
 es: { hint: "Toca el paisaje: el volcán, el agua, el atardecer…", hintM: "Desliza el paisaje y toca lo que te llame la atención", found: "Descubriste", more: "Seguir explorando", close: "Cerrar", add: "Agregar a mi viaje", inn: "En mi viaje ✓", detail: "Ver detalle",
  journey: "Mi viaje", empty: "Tu viaje está vacío. Descubre algo en el paisaje y agrégalo.", total: "Total de referencia (2 personas por defecto)", go: "Continuar a reserva", rm: "Quitar", disc: "Descubrimientos", note: "Contenido de ejemplo. Información y precios por confirmar.", scene: "Escena interactiva de Costa Rica", per: "p/p", grp: "grupo",
  h: { sunset: ["Atardecer", "Las playas del Pacífico se abren al poniente. Un buen momento para ir a caballo, en buggy o con una cena privada."],
       volcano: ["Volcán Arenal", "Cerca de La Fortuna, el Arenal domina la llanura del norte, con termas y senderos de selva a sus pies."],
       waterfall: ["Cataratas", "Agua que baja entre la selva, con pozas para nadar y caminos para llegar hasta ellas."],
       river: ["Río", "Los ríos del Pacífico central abren rutas de rafting y safaris en bote."],
       ocean: ["Océano Pacífico", "Olas para aprender a surfear, snorkel y pesca deportiva frente a Jacó."],
       animal: ["Fauna", "Guacamayas, tucanes y monos viven en los bosques y parques de la costa."],
       forest: ["Bosque", "Selva y bosque nuboso: caminatas, aves y parques nacionales."],
       adventure: ["Aventura", "Motos todoterreno, tirolesa y vuelo en parapente, con la selva de fondo."] } },
 en: { hint: "Touch the landscape: the volcano, the water, the sunset…", hintM: "Swipe the landscape and tap whatever catches your eye", found: "You discovered", more: "Keep exploring", close: "Close", add: "Add to my journey", inn: "In my journey ✓", detail: "View details",
  journey: "My journey", empty: "Your journey is empty. Discover something in the landscape and add it.", total: "Reference total (2 guests by default)", go: "Continue to booking", rm: "Remove", disc: "Discoveries", note: "Sample content. Information and prices to be confirmed.", scene: "Interactive scene of Costa Rica", per: "pp", grp: "group",
  h: { sunset: ["Sunset", "Pacific beaches open to the west. A great moment for horseback, a buggy ride or a private dinner."],
       volcano: ["Arenal Volcano", "Near La Fortuna, Arenal rises over the northern plains, with hot springs and jungle trails at its feet."],
       waterfall: ["Waterfalls", "Water tumbling through the jungle, with pools to swim in and trails to reach them."],
       river: ["River", "Central Pacific rivers open the way to white-water rafting and boat safaris."],
       ocean: ["Pacific Ocean", "Waves to learn surfing, snorkeling and sport fishing off Jacó."],
       animal: ["Wildlife", "Macaws, toucans and monkeys live in the forests and parks of the coast."],
       forest: ["Forest", "Jungle and cloud forest: hikes, birds and national parks."],
       adventure: ["Adventure", "ATVs, zip lines and tandem paragliding, with the jungle as a backdrop."] } }
};
const get = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } };
const put = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} };

function trees() {
  let seed = 7; const r = () => (seed = seed * 16807 % 2147483647) / 2147483647, cols = ["#0f3a26", "#15472f", "#1b5a3b"]; let o = "";
  for (let x = 400; x <= 1020; x += 30) { const y = 540 + r() * 60, rad = 22 + r() * 16;
    o += `<rect x="${x - 3}" y="${y}" width="6" height="${640 - y}" fill="#3b2a1a"/><circle cx="${x}" cy="${y}" r="${rad.toFixed(0)}" fill="${cols[Math.floor(r() * 3)]}"/>`; }
  return o;
}
function hs(h, L) {
  const [name] = TXT[L].h[h.id];
  return `<g class="hs" data-h="${h.id}" tabindex="0" role="button" aria-label="${name}" transform="translate(${h.x} ${h.y})"><circle class="hit" r="42"/><circle class="ring" r="15"/><circle class="dot" r="6"/><text y="-28" text-anchor="middle">${name}</text><g class="bd"><circle cx="24" cy="-20" r="12"/><text x="24" y="-15" text-anchor="middle" class="bn"></text></g></g>`;
}
const svg = inner => `<svg viewBox="0 0 1000 640" preserveAspectRatio="xMidYMax slice" aria-hidden="false">${inner}</svg>`;
const ly = (d, k, inner) => `<div class="ly" style="--d:${d}px;--k:${k}px">${svg(inner)}</div>`;
function art(L) {
  const g = id => hs(HS.find(h => h.id === id), L);
  return [
   ly(3, .03, `<defs><linearGradient id="gSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1d2b64"/><stop offset=".45" stop-color="#c8567a"/><stop offset=".62" stop-color="#f6a35a"/><stop offset="1" stop-color="#ffd9a0"/></linearGradient></defs><rect width="1000" height="640" fill="url(#gSky)"/><g class="cld"><ellipse cx="300" cy="120" rx="110" ry="16" fill="#fff" opacity=".22"/><ellipse cx="620" cy="80" rx="140" ry="14" fill="#fff" opacity=".18"/><ellipse cx="880" cy="190" rx="100" ry="12" fill="#fff" opacity=".2"/></g>`),
   ly(5, .03, `<defs><radialGradient id="gSun"><stop offset="0" stop-color="#fff2b0" stop-opacity=".9"/><stop offset="1" stop-color="#ffb35a" stop-opacity="0"/></radialGradient><linearGradient id="gSea" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e98a5a"/><stop offset=".25" stop-color="#2b78a8"/><stop offset="1" stop-color="#0d3f68"/></linearGradient></defs><circle cx="230" cy="300" r="110" fill="url(#gSun)"/><circle cx="230" cy="300" r="44" fill="#ffe08a"/><rect y="332" width="1000" height="308" fill="url(#gSea)"/><g fill="#ffd98a" opacity=".5"><ellipse cx="230" cy="344" rx="70" ry="4"/><ellipse cx="230" cy="362" rx="54" ry="4"/><ellipse cx="230" cy="384" rx="36" ry="4"/></g><g class="wav" fill="none" stroke="#fff" stroke-width="2" opacity=".28"><path d="M20,420 q40,-10 80,0 t80,0"/><path d="M200,500 q40,-10 80,0 t80,0"/><path d="M40,540 q40,-10 80,0 t80,0"/></g>${g("sunset")}${g("ocean")}`),
   ly(8, .04, `<path d="M470,440 C560,410 640,270 695,188 L735,188 C790,262 870,400 960,440Z" fill="#4a3b6b"/><path d="M695,188 C640,270 560,410 470,440 L540,440 C600,380 660,260 705,196Z" fill="#e0805a" opacity=".35"/><g class="smk" fill="#d9c9d8"><circle cx="715" cy="168" r="18" opacity=".5"/><circle cx="728" cy="140" r="24" opacity=".35"/><circle cx="742" cy="108" r="30" opacity=".22"/></g>${g("volcano")}`),
   ly(14, 0, `<path d="M0,560 C120,540 260,570 345,600 L360,640 L0,640Z" fill="#e8c88c"/><path d="M330,640 L330,500 C420,430 520,450 600,440 C700,430 780,410 840,420 C900,425 960,400 1000,380 L1000,640Z" fill="#1d5a3b"/><path d="M815,330 C826,360 818,390 822,424" stroke="#eafcff" stroke-width="9" fill="none" stroke-linecap="round"/><ellipse class="mst" cx="822" cy="426" rx="26" ry="9" fill="#fff" opacity=".5"/><path d="M822,426 C770,462 705,470 660,508 S520,568 400,590 S345,615 330,640" stroke="#6fc3e6" stroke-width="13" fill="none" stroke-linecap="round"/>${g("waterfall")}${g("river")}`),
   ly(22, -.03, `${trees()}${g("forest")}`),
   ly(26, -.05, `<path d="M380,640 C470,604 560,592 700,616 L760,640Z" fill="#8a5a34"/><g transform="translate(560 598)"><g class="dust" fill="#d9b88a" opacity=".5"><circle cx="-30" cy="6" r="7"/><circle cx="-44" cy="2" r="5"/></g><rect x="-22" y="-14" width="40" height="12" rx="4" fill="#d8402a"/><circle cx="-18" cy="0" r="9" fill="#222"/><circle cx="16" cy="0" r="9" fill="#222"/><circle cx="-2" cy="-26" r="6" fill="#f2c14e"/><rect x="-6" y="-22" width="9" height="10" rx="3" fill="#f2c14e"/></g>${g("adventure")}<g fill="none" stroke="#0f3a26" stroke-linecap="round" stroke-width="12"><path d="M40,640 C40,560 20,490 -20,440"/><path d="M40,640 C70,560 110,510 170,490"/><path d="M40,640 C50,570 70,500 100,440"/></g><path d="M1000,640 C930,590 880,560 820,590 C900,600 950,620 1000,640Z" fill="#0e3622"/><path d="M1000,150 L740,190" stroke="#4a2f1d" stroke-width="8" stroke-linecap="round"/><g transform="translate(800 162)"><ellipse rx="22" ry="15" fill="#1a1a1a"/><ellipse cx="6" cy="4" rx="10" ry="8" fill="#f4f1e6"/><circle cx="14" cy="-6" r="2.5" fill="#fff"/><path d="M18,-8 q40,-4 46,12 q-30,8 -46,-2Z" fill="#f28a1e"/></g>${g("animal")}`)
  ].join("");
}
function mount(root, ctx) {
  const L = ctx.lang(), T = TXT[L], items = ctx.items(), esc = ctx.esc, money = Core.money, small = () => innerWidth < 720;
  let journey = get("cofa_journey", []).filter(j => items.some(i => i.id === j.e)), seen = new Set(get("cofa_seen", [])), active = null, last = null;
  root.innerHTML = `<section class="scene" id="scene" aria-label="${T.scene}"><div class="stage" id="stage"><div class="world" id="world"><div class="zoomer" id="zoomer">${art(L)}</div></div></div><div class="mood"></div>
  <div class="hud"><span class="disc" id="disc"></span><button class="pill" id="pill" type="button" aria-expanded="false"></button></div>
  <div class="jd" id="jd" hidden></div><p class="hint" id="hint">${small() ? T.hintM : T.hint}</p>
  <aside class="panel" id="panel" role="dialog" aria-modal="false" hidden></aside></section>`;
  const $ = s => root.querySelector(s), scene = $("#scene"), stage = $("#stage"), world = $("#world"), zoomer = $("#zoomer"), panel = $("#panel"), jd = $("#jd");
  const hOf = id => HS.find(h => h.id === id), it = id => items.find(i => i.id === id), nm = id => T.h[id][0];
  const setH = () => { const hd = document.querySelector("header.top"); scene.style.setProperty("--hh", (hd ? hd.offsetHeight : 60) + "px"); };
  setH();
  stage.scrollLeft = Math.max(0, .78 * world.scrollWidth - stage.clientWidth / 2);

  function refresh() {
    $("#disc").textContent = `${T.disc} ${seen.size}/${HS.length}`;
    $("#pill").textContent = `${T.journey} · ${journey.length}`;
    root.querySelectorAll(".hs").forEach(g => { const id = g.dataset.h, i = journey.findIndex(j => j.h === id);
      g.classList.toggle("seen", seen.has(id)); g.classList.toggle("picked", i >= 0); if (i >= 0) g.querySelector(".bn").textContent = i + 1; });
    panel.querySelectorAll("[data-exp]").forEach(b => { const on = journey.some(j => j.e === b.dataset.exp); b.setAttribute("aria-pressed", on); b.textContent = on ? T.inn : T.add; });
    const tot = journey.reduce((s, j) => s + Core.lineTotal(it(j.e), 2), 0);
    jd.innerHTML = journey.length ? `<ol>${journey.map((j, i) => `<li><span class="num">${i + 1}</span><div><strong>${esc(it(j.e).title)}</strong><small>${esc(nm(j.h))}</small></div><button type="button" data-rm="${i}" aria-label="${T.rm}">×</button></li>`).join("")}</ol><p class="tt">${T.total}: <strong>${money(tot)}</strong></p><p class="n">${T.note}</p><button class="btn big" type="button" data-go>${T.go}</button>` : `<p>${T.empty}</p>`;
    put("cofa_journey", journey); put("cofa_seen", [...seen]);
  }
  function pos(h) {
    const W = world.clientWidth, Hh = world.clientHeight, lw = W * 1.12, s = Math.max(lw / VB[0], Hh / VB[1]);
    return { W, Hh, x: -.06 * W + (lw - VB[0] * s) / 2 + h.x * s, y: Hh - VB[1] * s + h.y * s };
  }
  function zoom(h) {
    const p = pos(h), S = small() ? 1.4 : 1.5, cw = stage.clientWidth, ch = stage.clientHeight, sl = stage.scrollLeft;
    let tx = sl + cw * (small() ? .5 : .36) - S * p.x, ty = ch * .34 - S * p.y;
    tx = Math.min(sl, Math.max(sl + cw - S * p.W, tx)); ty = Math.min(0, Math.max(ch - S * p.Hh, ty));
    zoomer.style.transform = `translate(${tx}px,${ty}px) scale(${S})`; stage.classList.add("lock");
  }
  function open(id, el) {
    const h = hOf(id); active = id; last = el; seen.add(id); $("#hint").hidden = true; jd.hidden = true; $("#pill").setAttribute("aria-expanded", "false");
    scene.dataset.mood = h.mood; zoom(h);
    panel.innerHTML = `<button class="x" type="button" data-close aria-label="${T.close}">×</button><p class="k">${T.found}</p><h2>${nm(id)}</h2><p>${T.h[id][1]}</p><ul>${h.ex.map(e => { const x = it(e); return x ? `<li><div><strong>${esc(x.title)}</strong><small>${esc(x.duration)} · ${x.priceOnRequest ? "" : ""}${money(x.price)} ${x.unit === "group" ? T.grp : T.per}${ctx.pricesConfirmed ? "" : " · *"}</small><a href="/experiences/${x.id}" data-link>${T.detail}</a></div><button class="btn sm" type="button" data-exp="${x.id}" data-h="${id}" aria-pressed="false"></button></li>` : ""; }).join("")}</ul><p class="n">${T.note}</p><button class="btn ghost" type="button" data-close>${T.more}</button>`;
    panel.hidden = false; requestAnimationFrame(() => panel.classList.add("on")); refresh(); panel.querySelector(".x").focus({ preventScroll: true });
  }
  function close() {
    if (!active) return; active = null; zoomer.style.transform = ""; stage.classList.remove("lock"); scene.dataset.mood = ""; panel.classList.remove("on");
    setTimeout(() => { if (!active) panel.hidden = true; }, 300); if (last && last.focus) last.focus({ preventScroll: true });
  }
  root.addEventListener("click", e => {
    const g = e.target.closest(".hs"); if (g) { open(g.dataset.h, g); return; }
    if (e.target.closest("[data-close]")) { close(); return; }
    const b = e.target.closest("[data-exp]");
    if (b) { const i = journey.findIndex(j => j.e === b.dataset.exp); if (i >= 0) journey.splice(i, 1); else journey.push({ e: b.dataset.exp, h: b.dataset.h }); refresh(); return; }
    const rm = e.target.closest("[data-rm]"); if (rm) { journey.splice(+rm.dataset.rm, 1); refresh(); return; }
    if (e.target.closest("[data-go]")) { journey.forEach(j => ctx.addToCart(j.e, 2)); ctx.nav("/cart"); return; }
    if (e.target.closest("#pill")) { jd.hidden = !jd.hidden; $("#pill").setAttribute("aria-expanded", String(!jd.hidden)); if (!jd.hidden) close(); }
  });
  root.addEventListener("keydown", e => { const g = e.target.closest && e.target.closest(".hs"); if (g && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); open(g.dataset.h, g); } });
  const onKey = e => { if (e.key === "Escape") { close(); jd.hidden = true; } }; document.addEventListener("keydown", onKey);
  // Parallax: solo transform; puntero (desktop) + scroll horizontal (móvil). Sin efecto si el usuario pide menos movimiento.
  let raf = 0, px = 0, py = 0;
  const upd = () => { raf = 0; world.style.setProperty("--px", px.toFixed(3)); world.style.setProperty("--py", py.toFixed(3)); world.style.setProperty("--sx", stage.scrollLeft); };
  const sched = () => { if (!raf) raf = requestAnimationFrame(upd); };
  stage.addEventListener("scroll", sched, { passive: true });
  scene.addEventListener("pointermove", e => { if (e.pointerType !== "mouse" || active) return; const r = scene.getBoundingClientRect(); px = (e.clientX - r.left) / r.width * 2 - 1; py = (e.clientY - r.top) / r.height * 2 - 1; sched(); }, { passive: true });
  const onRs = () => { setH(); if (active) zoom(hOf(active)); }; addEventListener("resize", onRs);
  refresh(); upd();
  return () => { document.removeEventListener("keydown", onKey); removeEventListener("resize", onRs); cancelAnimationFrame(raf); };
}
window.CofaScene = { mount, HS };
})();
