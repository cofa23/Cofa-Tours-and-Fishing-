const V = "cofa-v2", SHELL = ["/", "/styles.css", "/config.js", "/core.js", "/i18n.js", "/app.js", "/data/experiences.json", "/manifest.webmanifest", "/assets/logo.webp", "/assets/icon-192.png"];
self.addEventListener("install", e => { e.waitUntil(caches.open(V).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener("activate", e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== V).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener("fetch", e => {
  const r = e.request; if (r.method !== "GET") return;
  const u = new URL(r.url);
  if (r.mode === "navigate") { e.respondWith(fetch(r).catch(() => caches.match("/"))); return; } // SPA: offline devuelve el shell
  if (u.origin !== location.origin) { e.respondWith(fetch(r).catch(() => caches.match(r))); return; } // imágenes externas: red, sin cache opaco
  e.respondWith(caches.match(r).then(hit => { const net = fetch(r).then(res => { if (res.ok) caches.open(V).then(c => c.put(r, res.clone())); return res; }).catch(() => hit); return hit || net; }));
});
