// Lógica pura (sin DOM) para poder probarla en Node.
const Core = {
  lineTotal(it, qty) { return it.unit === "group" ? it.price : it.price * qty; },
  cartTotal(cart, items) {
    return cart.reduce((s, l) => { const it = items.find(i => i.id === l.id); return it ? s + Core.lineTotal(it, l.qty) : s; }, 0);
  },
  addToCart(cart, id, qty) {
    qty = Math.max(1, Math.min(50, parseInt(qty, 10) || 1));
    const c = cart.map(l => ({ ...l })), f = c.find(l => l.id === id);
    if (f) f.qty = Math.min(50, f.qty + qty); else c.push({ id, qty });
    return c;
  },
  setQty(cart, id, qty) {
    qty = parseInt(qty, 10);
    if (!qty || qty < 1) return cart.filter(l => l.id !== id);
    return cart.map(l => l.id === id ? { ...l, qty: Math.min(50, qty) } : { ...l });
  },
  remove(cart, id) { return cart.filter(l => l.id !== id); },
  validate(f, today) {
    const e = {};
    if (!f.name || f.name.trim().length < 2) e.name = "name";
    if (!/^\+?[\d\s().-]{7,20}$/.test(f.phone || "")) e.phone = "phone";
    if (f.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(f.email)) e.email = "email";
    if (!f.date || !/^\d{4}-\d{2}-\d{2}$/.test(f.date) || f.date <= today) e.date = "date";
    if (!(parseInt(f.guests, 10) >= 1)) e.guests = "guests";
    return e;
  },
  money(n) { return "$" + n.toLocaleString("en-US"); },
  message(lang, cart, items, f, total, cfg) {
    const es = lang === "es", L = [];
    L.push(es ? "Hola COFA Tours and Fishing! Quiero solicitar esta reserva:" : "Hello COFA Tours and Fishing! I'd like to request this booking:");
    cart.forEach(l => { const it = items.find(i => i.id === l.id); if (it) L.push(`- ${it.title} x${l.qty} (${Core.money(Core.lineTotal(it, l.qty))}${it.priceOnRequest ? (es ? ", a confirmar" : ", to confirm") : ""})`); });
    L.push(`${es ? "Fecha" : "Date"}: ${f.date}${f.time ? " " + f.time : ""}`);
    L.push(`${es ? "Personas" : "Guests"}: ${f.guests}`);
    L.push(`${es ? "Nombre" : "Name"}: ${f.name.trim()}`);
    L.push(`${es ? "Contacto" : "Contact"}: ${f.phone}${f.email ? " / " + f.email : ""}`);
    if (f.notes && f.notes.trim()) L.push(`${es ? "Observaciones" : "Notes"}: ${f.notes.trim()}`);
    L.push(`${es ? "Total de referencia" : "Reference total"}: ${Core.money(total)}${cfg.pricesConfirmed ? "" : (es ? " (precios por confirmar)" : " (prices to be confirmed)")}`);
    L.push(es ? "Por favor confirmen disponibilidad. Pura vida!" : "Please confirm availability. Pura vida!");
    return L.join("\n");
  },
  waUrl(num, text) { return `https://wa.me/${num}?text=${encodeURIComponent(text)}`; }
};
if (typeof module !== "undefined") module.exports = Core;
